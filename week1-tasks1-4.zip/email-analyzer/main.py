import json, sys
from pathlib import Path
from email_parser import parse_eml
from header_analyzer import analyze_headers

def main(paths):
    for p in paths:
        parsed, msg = parse_eml(p)
        if not parsed["parse_ok"]:
            print(f"[!] {p}: {parsed['errors']}")
            continue
        hdr = analyze_headers(parsed, msg)
        out = {"parsed": {k: v for k, v in parsed.items() if k not in ("body_text", "body_html")}, "headers": hdr}
        Path("output").mkdir(exist_ok=True)
        Path("output", Path(p).stem + ".json").write_text(json.dumps(out, indent=2, ensure_ascii=False))
        print(f"\n=== {Path(p).name} ===")
        print("From:", parsed["from"], "| Subject:", parsed["subject"])
        print("Auth:", hdr["facts"]["authentication"])
        print("Origin IPs:", hdr["facts"]["origin_ips"])
        for i in hdr["indicators"]:
            print("  -", i["indicator"], "->", i["evidence"])

if __name__ == "__main__":
    main(sys.argv[1:] or sorted(map(str, Path("samples").glob("*.eml"))))
