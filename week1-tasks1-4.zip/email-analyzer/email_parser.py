"""W1-02: Safe .eml parser. Never executes anything; attachments stay as bytes."""
from email import policy
from email.parser import BytesParser
from email.utils import parseaddr, getaddresses
from pathlib import Path
import hashlib


def parse_eml(path):
    raw = Path(path).read_bytes()
    result = {
        "file": str(path),
        "file_sha256": hashlib.sha256(raw).hexdigest(),
        "parse_ok": True,
        "errors": [],
    }
    try:
        msg = BytesParser(policy=policy.default).parsebytes(raw)
    except Exception as e:  # malformed input must not crash the tool
        result.update(parse_ok=False, errors=[f"parse error: {e}"])
        return result, None

    def addr(h):
        name, email = parseaddr(str(msg.get(h, "")))
        return {"display_name": name, "address": email.lower()} if (name or email) else None

    result.update({
        "from": addr("From"),
        "reply_to": addr("Reply-To"),
        "return_path": addr("Return-Path"),
        "to": [a for _, a in getaddresses([str(msg.get("To", ""))]) if a],
        "subject": str(msg.get("Subject", "")),
        "date": str(msg.get("Date", "")),
        "message_id": str(msg.get("Message-ID", "")),
        "body_text": "",
        "body_html": "",
        "attachments": [],
    })

    for part in msg.walk():
        if part.is_multipart():
            continue
        ctype = part.get_content_type()
        fname = part.get_filename()
        try:
            if fname or part.get_content_disposition() == "attachment":
                data = part.get_payload(decode=True) or b""
                result["attachments"].append({
                    "filename": fname,
                    "content_type": ctype,
                    "size": len(data),
                    "sha256": hashlib.sha256(data).hexdigest(),
                })
            elif ctype == "text/plain":
                result["body_text"] += part.get_content()
            elif ctype == "text/html":
                result["body_html"] += part.get_content()
        except Exception as e:
            result["errors"].append(f"part error ({ctype}): {e}")
    return result, msg
