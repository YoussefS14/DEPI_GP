import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from email_parser import parse_eml
from header_analyzer import analyze_headers

SAMPLES = Path(__file__).resolve().parent.parent / "samples"


def run(name):
    parsed, msg = parse_eml(SAMPLES / name)
    return parsed, analyze_headers(parsed, msg)


def names(hdr):
    return {i["indicator"] for i in hdr["indicators"]}


def test_benign_all_pass_no_indicators():
    parsed, hdr = run("benign_001.eml")
    assert hdr["facts"]["authentication"] == {"spf": "pass", "dkim": "pass", "dmarc": "pass"}
    assert hdr["indicators"] == []


def test_phish_indicators():
    parsed, hdr = run("phish_001.eml")
    n = names(hdr)
    assert {"reply_to_mismatch", "return_path_mismatch", "spf_fail", "dmarc_fail"} <= n
    assert hdr["facts"]["origin_ips"] == ["203.0.113.45"]


def test_phish_attachment_hash():
    parsed, _ = run("phish_001.eml")
    att = parsed["attachments"][0]
    assert att["filename"] == "Invoice_2026.pdf.exe"
    assert len(att["sha256"]) == 64


def test_incomplete_does_not_crash_and_is_unknown():
    parsed, hdr = run("incomplete_001.eml")
    assert parsed["parse_ok"]
    assert hdr["facts"]["authentication"] == {"spf": "unknown", "dkim": "unknown", "dmarc": "unknown"}
    assert "no_received_headers" in names(hdr)


def test_malformed_does_not_crash():
    parsed, hdr = run("malformed_001.eml")
    assert "file_sha256" in parsed
    assert isinstance(hdr["indicators"], list)
