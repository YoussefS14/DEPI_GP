# Email Analyzer - Week 1 (Tasks 1-4)

Completed: W1 sample preparation, Python environment, email parser, header analysis.

## Run
    python -m venv venv
    venv\Scripts\activate
    pip install pytest
    python make_samples.py
    python main.py
    python -m pytest -q

## Contents
- make_samples.py    : generates safe synthetic .eml samples (reserved domains only)
- email_parser.py    : safe .eml parsing (headers, bodies, attachment metadata + SHA-256; nothing executed)
- header_analyzer.py : Received chain, Authentication-Results (as recorded), heuristic indicators
- main.py            : runs parser + header analysis, writes JSON per sample to output/
- tests/test_parser.py : 5 tests (benign, phishing, incomplete, malformed)
- sample_inventory.csv : sample provenance
- output/            : analysis results (JSON + console output)

## Limitations
- Samples are synthetic; not yet validated on real-world emails.
- SPF/DKIM/DMARC values are read from Authentication-Results only (no DNS lookups or alignment checks yet).
- URL, attachment-type and macro analysis, IOC extraction and risk scoring are not implemented yet.
