"""W1-03: Header analysis. Reports facts + heuristic indicators separately."""
import re
from email.utils import parseaddr

IP_RE = re.compile(r"\[?((?:\d{1,3}\.){3}\d{1,3})\]?")
AUTH_RE = {
    "spf": re.compile(r"\bspf=(\w+)", re.I),
    "dkim": re.compile(r"\bdkim=(\w+)", re.I),
    "dmarc": re.compile(r"\bdmarc=(\w+)", re.I),
}


def _domain(addr):
    return addr.rsplit("@", 1)[1].lower() if addr and "@" in addr else None


def analyze_headers(parsed, msg):
    facts, indicators = {}, []
    if msg is None:
        return {"facts": facts, "indicators": indicators}

    # Received chain (top = last hop, so reverse for chronological order)
    hops = []
    for h in reversed(msg.get_all("Received", [])):
        h = " ".join(str(h).split())
        hops.append({"raw": h, "ips": IP_RE.findall(h)})
    facts["received_chain"] = hops
    facts["origin_ips"] = hops[0]["ips"] if hops else []

    # Authentication-Results: record exactly what is there, 'none' if absent
    ar = " ".join(str(x) for x in msg.get_all("Authentication-Results", []))
    auth = {k: (m.group(1).lower() if (m := rx.search(ar)) else "unknown") for k, rx in AUTH_RE.items()}
    facts["authentication"] = auth
    facts["has_dkim_signature_header"] = msg.get("DKIM-Signature") is not None  # presence != valid

    frm, rp, ret = parsed.get("from"), parsed.get("reply_to"), parsed.get("return_path")
    fd = _domain(frm["address"]) if frm else None
    rpd = _domain(rp["address"]) if rp else None
    retd = _domain(ret["address"]) if ret else None
    facts.update(from_domain=fd, reply_to_domain=rpd, return_path_domain=retd)

    def ind(name, evidence):
        indicators.append({"indicator": name, "evidence": evidence, "type": "heuristic"})

    if rpd and fd and rpd != fd:
        ind("reply_to_mismatch", f"From domain={fd}, Reply-To domain={rpd}")
    if retd and fd and retd != fd:
        ind("return_path_mismatch", f"From domain={fd}, Return-Path domain={retd}")
    if frm and frm["display_name"]:
        dn_dom = re.search(r"[\w.-]+\.[a-z]{2,}", frm["display_name"], re.I)
        if dn_dom and fd and dn_dom.group(0).lower() != fd:
            ind("display_name_domain_mismatch", frm["display_name"])
    for k, v in auth.items():
        if v in ("fail", "softfail", "permerror"):
            ind(f"{k}_{v}", f"Authentication-Results reports {k}={v}")
        elif v == "unknown":
            ind(f"{k}_not_reported", f"No {k} result in headers (not proof of malicious)")
    if not msg.get_all("Received"):
        ind("no_received_headers", "Received chain missing")
    if not parsed.get("message_id"):
        ind("missing_message_id", "Message-ID header absent")
    return {"facts": facts, "indicators": indicators}
